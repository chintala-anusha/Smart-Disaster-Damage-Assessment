# Smart Disaster Damage Assessment

A Flask + TensorFlow computer-vision project that classifies disaster images as **damaged** or **not damaged** using MobileNetV2 transfer learning.

## Run
1. Create a virtual environment.
2. `pip install -r requirements.txt`
3. Put labeled images in:
   `dataset/train/damaged`, `dataset/train/not_damaged`,
   `dataset/validation/damaged`, `dataset/validation/not_damaged`
4. Run `python train_model.py`
5. Run `python app/app.py`
6. Open `http://127.0.0.1:5000`

The included folders are empty because a real model must be trained on a properly labeled disaster dataset. Do not claim accuracy without evaluating it on an independent test set.

## Pipeline
Image → preprocessing → MobileNetV2 transfer learning → damage classification → confidence/severity → Flask UI.

## Future upgrades
Multi-class severity, disaster-type classification, segmentation, GIS mapping, Grad-CAM explainability, prediction history, and human verification.
