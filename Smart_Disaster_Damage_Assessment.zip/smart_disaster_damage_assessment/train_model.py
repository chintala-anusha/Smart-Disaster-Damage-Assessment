import os,json,tensorflow as tf
from tensorflow.keras import layers,models
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

ROOT=os.path.dirname(os.path.abspath(__file__))
train_dir=os.path.join(ROOT,"dataset","train")
val_dir=os.path.join(ROOT,"dataset","validation")
model_dir=os.path.join(ROOT,"model"); os.makedirs(model_dir,exist_ok=True)
size=(224,224); batch=32

train=tf.keras.utils.image_dataset_from_directory(train_dir,image_size=size,batch_size=batch,label_mode="binary",seed=42)
val=tf.keras.utils.image_dataset_from_directory(val_dir,image_size=size,batch_size=batch,label_mode="binary",shuffle=False)
classes=train.class_names
train=train.prefetch(tf.data.AUTOTUNE); val=val.prefetch(tf.data.AUTOTUNE)

base=MobileNetV2(input_shape=size+(3,),include_top=False,weights="imagenet")
base.trainable=False
inp=layers.Input(shape=size+(3,))
x=layers.RandomFlip("horizontal")(inp); x=layers.RandomRotation(.08)(x); x=layers.RandomZoom(.12)(x)
x=preprocess_input(x); x=base(x,training=False); x=layers.GlobalAveragePooling2D()(x); x=layers.Dropout(.25)(x)
out=layers.Dense(1,activation="sigmoid")(x)
model=models.Model(inp,out)
model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),loss="binary_crossentropy",metrics=["accuracy",tf.keras.metrics.Precision(),tf.keras.metrics.Recall()])
model.fit(train,validation_data=val,epochs=12,callbacks=[
 tf.keras.callbacks.EarlyStopping(monitor="val_loss",patience=3,restore_best_weights=True),
 tf.keras.callbacks.ModelCheckpoint(os.path.join(model_dir,"damage_classifier.keras"),monitor="val_loss",save_best_only=True)])
json.dump(classes,open(os.path.join(model_dir,"classes.json"),"w"))
print("Saved trained model.")
