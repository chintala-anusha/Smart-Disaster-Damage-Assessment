import os,json,numpy as np
from PIL import Image
from flask import Flask,render_template,request,jsonify
import tensorflow as tf
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL=os.path.join(ROOT,"model","damage_classifier.keras")
CLASS=os.path.join(ROOT,"model","classes.json")
UPLOAD=os.path.join(os.path.dirname(__file__),"static","uploads"); os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__); app.config["MAX_CONTENT_LENGTH"]=10*1024*1024
model=tf.keras.models.load_model(MODEL) if os.path.exists(MODEL) else None
classes=json.load(open(CLASS)) if os.path.exists(CLASS) else ["damaged","not_damaged"]

@app.route("/")
def home(): return render_template("index.html")

@app.route("/predict",methods=["POST"])
def predict():
    if model is None: return jsonify(error="Train the model first by running: python train_model.py"),400
    f=request.files.get("image")
    if not f or not f.filename: return jsonify(error="Please upload an image"),400
    ext=os.path.splitext(f.filename)[1].lower()
    if ext not in [".jpg",".jpeg",".png",".webp"]: return jsonify(error="Use JPG, PNG or WEBP"),400
    path=os.path.join(UPLOAD,"assessment"+ext); f.save(path)
    im=Image.open(path).convert("RGB").resize((224,224))
    x=np.asarray(im,dtype=np.float32)/255.0; x=np.expand_dims(x,0)
    s=float(model.predict(x,verbose=0)[0][0])
    probs={classes[0]:s,classes[1]:1-s}; pred=max(probs,key=probs.get); conf=probs[pred]*100
    severity="High" if pred=="damaged" and conf>=85 else ("Moderate" if pred=="damaged" and conf>=65 else ("Low" if pred=="damaged" else "None detected"))
    return jsonify(prediction=pred.replace("_"," ").title(),confidence=round(conf,2),severity=severity,
      action="Prioritize human inspection." if pred=="damaged" else "No damage class detected; human verification is recommended.")
@app.route("/health")
def health(): return jsonify(status="ok",model_loaded=model is not None)
if __name__=="__main__": app.run(debug=True,host="127.0.0.1",port=5000)
